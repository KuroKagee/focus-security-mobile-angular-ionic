package com.sgeede.focus.security.plugin;

import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.content.Context;
import android.util.Log;
import android.media.AudioManager;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

@CapacitorPlugin(name = "Ringtone")
public class RingtonePlugin extends Plugin {

    private Ringtone ringtone;
    private AudioManager audioManager;

    @Override
    public void load() {
        audioManager = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
    }

    @PluginMethod
    public void setSpeakerOn(PluginCall call) {
        Log.e("RingtonePlugin", "set speaker on");
        if (audioManager != null) {
            Log.e("RingtonePlugin", "masuk ke if");
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            audioManager.setSpeakerphoneOn(true);
            call.resolve();
        } else {
            Log.e("RingtonePlugin", "masuk ke else");
            call.reject("AudioManager not available");
        }
    }

    @PluginMethod
    public void setEarpieceOn(PluginCall call) {
        Log.e("RingtonePlugin", "set earpiece on");
        if (audioManager != null) {
            Log.e("RingtonePlugin", "masuk ke if");
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            audioManager.setSpeakerphoneOn(false);
            call.resolve();
        } else {
            Log.e("RingtonePlugin", "masuk ke else");
            call.reject("AudioManager not available");
        }
    }

   @PluginMethod
    public void play(PluginCall call) {
        Log.e("RingtonePlugin", "play() dipanggil");
        Context context = getContext();
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        ringtone = RingtoneManager.getRingtone(context, notification);
        if (ringtone != null && !ringtone.isPlaying()) {
            ringtone.play();
        }
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        Log.e("RingtonePlugin", "stop() dipanggil");
        if (ringtone != null && ringtone.isPlaying()) {
            ringtone.stop();
        }
        call.resolve();
    }
}