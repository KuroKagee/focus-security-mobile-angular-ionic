package com.sgeede.focus.security;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import android.util.Log;
import com.sgeede.focus.security.MyFirebaseMessagingService;
import java.util.ArrayList;
import com.getcapacitor.Plugin;
import android.app.NotificationManager;
import android.content.Context;
import com.sgeede.focus.security.plugin.RingtonePlugin;


public class MainActivity extends BridgeActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }

        registerPlugin(RingtonePlugin.class);
        super.onCreate(savedInstanceState);
        getWindow().addFlags(
            android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
            android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );
        handleIntent(getIntent());
        handleNotificationIntent(getIntent());
        
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleNotificationIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) {
            return;
        }

        Bundle extras = intent.getExtras();
        if (extras != null && extras.containsKey("callAction")) {
            NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.cancel(3001);
            MyFirebaseMessagingService.stopRingtone();
            Log.e("MainActivity", "Masukkk: ");
            String callAction = intent.getStringExtra("callAction");
            String receiverName = intent.getStringExtra("receiverName");
            String callerSocketId = intent.getStringExtra("callerSocketId");
            String callerName = intent.getStringExtra("callerName");
            Log.e("MainActivity", "callAction received here: " + callAction);
            if (bridge.getWebView() != null) {
                bridge.getWebView().post(() -> {
                    String js =
                        "let existingData = localStorage.getItem('callData');" +
                        "let newCall = { callAction: '" + callAction + "', callerName: '" + callerName +
                        "', receiverName: '" + receiverName + "', callerSocketId: '" + callerSocketId + "' };" +
                        "if (existingData) {" +
                        "    let parsedData = JSON.parse(existingData);" +
                        "    if (!Array.isArray(parsedData)) { parsedData = [parsedData]; }" +
                        "    parsedData.push(newCall);" +
                        "    localStorage.setItem('callData', JSON.stringify(parsedData));" +
                        "} else {" +
                        "    localStorage.setItem('callData', JSON.stringify([newCall]));" +
                        "}";
                    bridge.getWebView().evaluateJavascript(js, null);
                });
            }
        }
    }

    private void handleNotificationIntent(Intent intent) {
        if (intent != null) {
            // Check jika dari notifikasi
            if (intent.getBooleanExtra("from_notification", false)) {
                String notificationData = intent.getStringExtra("notification_data");
                Log.d("MainActivity", "Dibuka dari notifikasi: " + notificationData);
                
                // Lakukan action khusus di sini
                // Misalnya: buka halaman tertentu, tampilkan dialog, dll
            }
            
            // Atau check dengan action
            if ("NOTIFICATION_CLICKED".equals(intent.getAction())) {
                Bundle extras = intent.getExtras();
                if (extras != null) {
                    String title = extras.getString("title");
                    String body = extras.getString("body");
                    Log.d("MainActivity", "Notification clicked - Title: " + title + ", Body: " + body);
                    
                    // Handle sesuai kebutuhan
                }
            }
        }
    }

}
